class customer:
	def __init__(self,name='',balance=0):
		self.name = name
		self.balance = balance 
	def getname(self):
		return self.name
	def getbalance(self):
		return self.balance
