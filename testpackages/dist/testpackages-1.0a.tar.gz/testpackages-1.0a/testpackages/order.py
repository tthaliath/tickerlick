class order:
	def __init__(self,item='',qty=0,price=0):
		self.item=item
		self.qty=qty
		self.price=0
	def setorder(item,qty,price):
		self.item=item
		self.qty=qty
		self.price=price
