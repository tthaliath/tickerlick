#!/usr/bin/env python
from distutils.core import setup
long_description = 'generate stick buy/sell signals'
setup(name = 'tradevantage',
	version = '1.0a',
	description = 'generate stick buy/sell signals',
	maintainer = 'Thomas Thaliath',
	maintainer_email = 'tthaliath@gmail.com',
	url = 'http://www.tickerlick.com',
	long_description = long_description,
	packages = ['tradevantage']
	)
