class GenSignals:
	def setticker(self,ticker):
		self.ticker = ticker
