class WebCrawler:
	def __init__(self,burl=''):
		self.burl = burl 
	def setticker(self,ticker):
		self.qurl = self.burl + ticker
	def geturl(self):
		return self.qurl
